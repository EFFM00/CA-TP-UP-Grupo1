#!/bin/sh
# Script to create backups

if [ "$1" = "-h" ] && [ "$#" -ne 1 ]; then
    echo "El flag -h no se puede usar junto con otros argumentos"
    exit 0

elif [ "$1" = "-h" ] && [ "$#" -eq 1 ]; then
    echo " "
    echo "  Ayuda para usar $0"
    echo "___________________________________________"
    echo " "
    echo "  ORIGEN    Directorio de origen para el backup"
    echo "  DESTINO   Directorio de destino donde se almacenará el backup"
    echo " "
    echo "  Ejemplo: $0 [ORIGEN] [DESTINO]"
    echo " "
    echo "  -h        Muestra este menú"
    echo " "
    echo "___________________________________________"
    echo " "
    exit 0
fi

if [ "$#" -ne 2 ]; then
    echo "Debe pasarse solo 2 argumentos: una ruta de origen y una de destino"
    exit 0
fi

ORIGEN="$1"
DESTINO="$2"

if [ ! -d $ORIGEN ]; then
    echo "'$ORIGEN' no es un directorio válido"
    exit 1
fi

if [ ! -d $DESTINO ]; then
    echo "'$DESTINO' no es un directorio válido"
    exit 1
fi

ANSI_DATE=$(date +%Y%m%d)

cd $ORIGEN

CURRENT_PATH=$(pwd)
DIR_NAME=$(basename $CURRENT_PATH)
FILE_NAME=${DIR_NAME}_bkp_${ANSI_DATE}.tar.gz

tar -czf "$DESTINO/$FILE_NAME" *

if [ $? -eq 0 ]; then
    echo " "
    echo "El archivo $FILE_NAME se guardó exitosamente en la ruta $DESTINO"
    exit 0
else
    echo "Falló la creación del archivo"
    exit 1
fi
